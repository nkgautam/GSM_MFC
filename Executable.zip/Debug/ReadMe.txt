Step1: connect mobile to usb port. 
step2: wait till driver get install 
step3: open control panel->Phone and modem options
step4: click on modem tab
step5: see your Modem and note "attached to" com port ex: COM15
step6: run GsmMFC app
step7: enter COM port, then click "open port" button.
step8: click on  "Send cmd" button

Expected output: Mobile Make and model number for me "Nokia E71" "OK"

check this app with other model 